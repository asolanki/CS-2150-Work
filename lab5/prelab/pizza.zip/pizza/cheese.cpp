#include "cheese.h"

Cheese::Cheese(){
    quantity=0;
}

Cheese::Cheese(int amount)
{
    quantity=amount;
}
