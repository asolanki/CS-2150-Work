#include "mushrooms.h"

Mushrooms::Mushrooms(){
    quantity=0;
}

Mushrooms::Mushrooms(int amount)
{
    quantity=amount;
}
