#ifndef MUSHROOMS_H
#define MUSHROOMS_H
class Mushrooms
{
private:
    int quantity;
public:
    Mushrooms();
    Mushrooms(int amount);
};
#endif
