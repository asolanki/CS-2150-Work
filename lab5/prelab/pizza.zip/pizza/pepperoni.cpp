#include "pepperoni.h"

Pepperoni::Pepperoni(){
    quantity=0;
}

Pepperoni::Pepperoni(int amount)
{
    quantity=amount;
}
