#ifndef PEPPERS_H
#define PEPPERS_H
class Peppers
{
private:
    int quantity;
public:
    Peppers();
    Peppers(int amount);
};
#endif
